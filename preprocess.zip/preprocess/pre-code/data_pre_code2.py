import os
import pandas as pd
from Bio.PDB import PDBParser


# 一位到三位
one_to_three = {"A": "ALA",
                "C": "CYS",
                "D": "ASP",
                "E": "GLU",
                "F": "PHE",
                "G": "GLY",
                "H": "HIS",
                "I": "ILE",
                "K": "LYS",
                "L": "LEU",
                "M": "MET",
                "N": "ASN",
                "P": "PRO",
                "Q": "GLN",
                "R": "ARG",
                "S": "SER",
                "T": "THR",
                "V": "VAL",
                "W": "TRP",
                "Y": "TYR",
                "B": "ASX",
                "Z": "GLX",
                "X": "UNK",
                "*": " * "}
# 三位到一位
three_to_one = {}
for _key, _value in one_to_three.items():
    three_to_one[_value] = _key
three_to_one["SEC"] = "C"
three_to_one["MSE"] = "M"

biopython_parser = PDBParser()


# 解析pdb，提取蛋白质结构信息，包括各链的氨基酸序列。
def extract_pdb_seq(protein_path):
    if not os.path.exists(protein_path):
        raise FileNotFoundError(f"The file {protein_path} does not exist.")
    structure = biopython_parser.get_structure('random_id', protein_path)[0]
    seq = ''
    chain_str = ''  # 蛋白质结构中各个链的标识字符串
    for i, chain in enumerate(structure):
        for res_idx, residue in enumerate(chain):
            if residue.get_resname() == 'HOH':
                continue
            residue_coords = []
            c_alpha, n, c = None, None, None
            for atom in residue:  # 只有满足下面三个条件的氨基酸才添加到序列中
                if atom.name == 'CA':
                    c_alpha = list(atom.get_vector())
                if atom.name == 'N':
                    n = list(atom.get_vector())
                if atom.name == 'C':
                    c = list(atom.get_vector())
            if c_alpha!= None and n!= None and c!= None:  # only append residue if it is an amino acid and not
                try:
                    seq += three_to_one[residue.get_resname()]
                    chain_str += str(chain.id)
                except Exception as e:  # 如果类型识别不了，替换成X
                    seq += 'X'
                    chain_str += str(chain.id)
                    print("encountered unknown AA: ", residue.get_resname(), ' in the complex. Replacing it with a dash X.')

    return seq, chain_str


def main():
    base_path = os.path.abspath(os.path.dirname(os.getcwd()))
    seq_path ="/home/liya/Other/data/core2013/"
    if not os.path.exists(seq_path):
        raise FileNotFoundError(f"The directory {seq_path} does not exist.")
    data_dir = os.path.join(base_path, 'data')
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    seq_data_path = os.path.join(data_dir,'core2013.csv')
    files = os.listdir(seq_path)
    pdb_id = []
    pdb_smi = []
    pdb_protein = []
    for pdb_file in files:
        if pdb_file == 'index':
            continue
        total_path = os.path.join(seq_path, pdb_file)
        mol_path = os.path.join(total_path, pdb_file + r'_ligand.smi')
        if not os.path.exists(mol_path):
            print(f"Warning: {mol_path} does not exist, skipping this ligand.")
            continue
        with open(mol_path) as mol:
            line = mol.readline()
            pdb_smi.append(line.split()[0])
        protein_path = os.path.join(total_path, pdb_file + r'_protein.pdb')
        try:
            protein_seq, _ = extract_pdb_seq(protein_path)
            pdb_id.append(pdb_file)
            pdb_protein.append(protein_seq)
        except FileNotFoundError as e:
            print(f"Error: {e}, skipping this protein.")
    data = {"PDBname": pdb_id, "Smile": pdb_smi, "Sequence": pdb_protein}
    frame = pd.DataFrame(data)
    frame.to_csv(seq_data_path, index=False)


if __name__ == "__main__":
    main()
